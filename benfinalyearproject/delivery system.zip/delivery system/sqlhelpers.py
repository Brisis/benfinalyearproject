from app import mysql, session
from blockchain import Block, Blockchain
import datetime

#custom exceptions for transaction errors
class InvalidTransactionException(Exception): pass
class InsufficientFundsException(Exception): pass

#what a mysql table looks like. Simplifies access to the database 'crypto'
class Table():
    #specify the table name and columns
    #EXAMPLE table:
    #               blockchain
    # number    hash    previous   data    nonce
    # -data-   -data-    -data-   -data-  -data-
    #
    #EXAMPLE initialization: ...Table("blockchain", "number", "hash", "previous", "data", "nonce")
    def __init__(self, table_name, *args):
        self.table = table_name
        self.columns = "(%s)" %",".join(args)
        self.columnsList = args

        #if table does not already exist, create it.
        if isnewtable(table_name):
            create_data = ""
            for column in self.columnsList:
                create_data += "%s varchar(300)," %column

            cur = mysql.connection.cursor() #create the table
            cur.execute("CREATE TABLE %s(%s)" %(self.table, create_data[:len(create_data)-1]))
            cur.close()

    #get all the values from the table
    def getall(self):
        cur = mysql.connection.cursor()
        result = cur.execute("SELECT * FROM %s" %self.table)
        data = cur.fetchall(); return data

    #get one value from the table based on a column's data
    #EXAMPLE using blockchain: ...getone("hash","00003f73gh93...")
    def getone(self, search, value):
        data = {}; cur = mysql.connection.cursor()
        result = cur.execute("SELECT * FROM %s WHERE %s = \"%s\"" %(self.table, search, value))
        if result > 0: data = cur.fetchone()
        cur.close(); return data

    #delete a value from the table based on column's data
    def deleteone(self, search, value):
        cur = mysql.connection.cursor()
        cur.execute("DELETE from %s where %s = \"%s\"" %(self.table, search, value))
        mysql.connection.commit(); cur.close()

    #delete all values from the table.
    def deleteall(self):
        self.drop() #remove table and recreate
        self.__init__(self.table, *self.columnsList)

    #remove table from mysql
    def drop(self):
        cur = mysql.connection.cursor()
        cur.execute("DROP TABLE %s" %self.table)
        cur.close()

    #insert values into the table
    def insert(self, *args):
        data = ""
        for arg in args: #convert data into string mysql format
            data += "\"%s\"," %(arg)

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO %s%s VALUES(%s)" %(self.table, self.columns, data[:len(data)-1]))
        mysql.connection.commit()
        cur.close()

#execute mysql code from python
def sql_raw(execution):
    cur = mysql.connection.cursor()
    cur.execute(execution)
    mysql.connection.commit()
    cur.close()

#check if table already exists
def isnewtable(tableName):
    cur = mysql.connection.cursor()

    try: #attempt to get data from table
        result = cur.execute("SELECT * from %s" %tableName)
        cur.close()
    except:
        return True
    else:
        return False

#check if user already exists
def isnewuser(account):
    #access the users table and get all values from column "account"
    users = Table("users", "name", "address", "account", "email", "username", "password", "public_key", "private_key")
    data = users.getall()
    accounts = [user.get('account') for user in data]

    return False if account in accounts else True

#send money from one user to another
def send_money(sender, recipient, amount):
    #verify that the amount is an integer or floating value
    try: amount = float(amount)
    except ValueError:
        raise InvalidTransactionException("Invalid Transaction.")

    #verify that the user has enough money to send (exception if it is the BANK)
    if amount > get_balance(sender) and sender != "BANK":
        raise InsufficientFundsException("Insufficient Funds.")

    #verify that the user is not sending money to themselves or amount is less than or 0
    elif sender == recipient or amount <= 0.00:
        raise InvalidTransactionException("Invalid Transaction.")

    #verify that the recipient exists
    elif isnewuser(recipient):
        raise InvalidTransactionException("User Does Not Exist.")

    #update the blockchain and sync to mysql
    blockchain = get_blockchain()
    number = len(blockchain.chain) + 1
    data = "%s-->%s-->%s" %(sender, recipient, amount)
    blockchain.mine(Block(number, data=data, timestamp=datetime.datetime.now()))
    sync_blockchain(blockchain)

#send money from one user to another
def sign_txn(sender, recipient, amount, reference_number):
    # users = Table("users", "name", "address", "account", "email", "username", "password", "public_key", "private_key")

    # sender = users.getone("account", sender)
    # recipient = users.getone("account", recipient)

    #verify that the amount is an integer or floating value
    try: amount = float(amount)
    except ValueError:
        raise InvalidTransactionException("Invalid Transaction.")

    #verify that the user has enough money to send (exception if it is the BANK)
    if amount > get_balance(sender) and sender != "BANK":
        raise InsufficientFundsException("Insufficient Funds.")

    #verify that the user is not sending money to themselves or amount is less than or 0
    elif sender == recipient or amount <= 0.00:
        raise InvalidTransactionException("Invalid Transaction.")

    #verify that the recipient exists
    elif isnewuser(recipient):
        raise InvalidTransactionException("User Does Not Exist.")

    # ===> SIGNED DELIVERY ===> %s

    #update the blockchain and sync to mysql
    blockchain = get_blockchain()
    number = len(blockchain.chain) + 1
    data = "%s-->%s-->%s ===> SIGNED DELIVERY ===> %s" %(sender, recipient, amount, reference_number)
    blockchain.mine(Block(number, data=data, timestamp=datetime.datetime.now()))
    sync_blockchain(blockchain)

#send money from one user to another
def send_delivery_request(sender, recipient, reference_number):
    # users = Table("users", "name", "address", "account", "email", "username", "password", "public_key", "private_key")

    # user = users.getone("account", sender)
    # receiver = users.getone("account", recipient)

    #verify that the user has enough money to send (exception if it is the BANK)
    if get_balance(sender) < 10:
        raise InsufficientFundsException("Insufficient Funds.")

    #verify that the recipient exists
    elif isnewuser(recipient):
        raise InvalidTransactionException("User Does Not Exist.")

    #update the blockchain and sync to mysql
    blockchain = get_blockchain()
    number = len(blockchain.chain) + 1
    data = "%s ==> %s REQUEST %s" %(sender, recipient, reference_number)
    blockchain.mine(Block(number, data=data, timestamp=datetime.datetime.now()))
    sync_blockchain(blockchain)

#send money from one user to another
def send_delivery_acceptance(sender, recipient, reference_number):
    # users = Table("users", "name", "address", "account", "email", "username", "password", "public_key", "private_key")

    # user = users.getone("account", sender)
    # receiver = users.getone("account", recipient)

    #verify that the recipient exists
    if isnewuser(recipient):
        raise InvalidTransactionException("User Does Not Exist.")

    #update the blockchain and sync to mysql
    blockchain = get_blockchain()
    number = len(blockchain.chain) + 1
    data = "%s ==> %s ACCEPTED %s" %(sender, recipient, reference_number)
    blockchain.mine(Block(number, data=data, timestamp=datetime.datetime.now()))
    sync_blockchain(blockchain)

#send money from one user to another
def send_delivery_approval(sender, recipient, pickup_account, reference_number):
    # users = Table("users", "name", "address", "account", "email", "username", "password", "public_key", "private_key")

    # user = users.getone("account", sender)

    # receiver = users.getone("account", recipient)
    # pickup_account = users.getone("account", pickup_account)

    #verify that the recipient exists
    if isnewuser(recipient):
        raise InvalidTransactionException("User Does Not Exist.")

    #update the blockchain and sync to mysql
    blockchain = get_blockchain()
    number = len(blockchain.chain) + 1
    data = "%s ==> %s ==> %s APPROVED %s" %(sender, recipient, pickup_account, reference_number)
    blockchain.mine(Block(number, data=data, timestamp=datetime.datetime.now()))
    sync_blockchain(blockchain)

#get the balance of a user
def get_balance(account):
    balance = 0.00
    #loop through the blockchain and update balance
    for block in get_blockchain().chain:
        if "-->" in block.data:
            data = block.data.split("-->")
            if account == data[0]:
                if "===>" in data[2]:
                    money = data[2].split("===>")
                    balance -= float(money[0])
                else:
                    balance -= float(data[2])
            elif account == data[1]:
                if "===>" in data[2]:
                    money = data[2].split("===>")
                    balance += float(money[0])
                else:
                    balance += float(data[2])

    return balance

#get the blockchain from mysql and convert to Blockchain object
def get_blockchain():
    blockchain = Blockchain()
    blockchain_sql = Table("blockchain", "number", "hash", "previous", "data", "nonce", "timestamp")

    for b in blockchain_sql.getall():
        blockchain.add(Block(int(b.get('number')), b.get('previous'), b.get('data'), int(b.get('nonce')), b.get("timestamp")))

    return blockchain

#update blockchain in mysql table
def sync_blockchain(blockchain):
    blockchain_sql = Table("blockchain", "number", "hash", "previous", "data", "nonce", "timestamp")
    blockchain_sql.deleteall()

    for block in blockchain.chain:
        blockchain_sql.insert(str(block.number), block.hash(), block.previous_hash, block.data, block.nonce, block.timestamp)
