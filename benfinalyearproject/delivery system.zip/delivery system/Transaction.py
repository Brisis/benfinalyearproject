from collections import OrderedDict

import binascii

from Crypto.Hash import SHA
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5


class Transaction:
    def __init__(self, sender_address, sender_private_key, recipient_address, reference_number):
        self.sender_address = sender_address
        self.sender_private_key = sender_private_key
        self.recipient_address = recipient_address
        self.reference_number = reference_number

     #returns a string of the transaction's data. Useful for diagnostic print statements.
    def __str__(self):
        return str("Sender: %s\nRecipient: %s\nReference: %s\n" %(
            self.sender_address,
            self.recipient_address,
            self.reference_number
            )
        )

    def sign_transaction(self):
        """Sign transaction with private key"""
        private_key = RSA.importKey(binascii.unhexlify(self.sender_private_key))
        signer = PKCS1_v1_5.new(private_key)

        hash = SHA.new(str(self).encode("utf8"))
        return binascii.hexlify(signer.sign(hash)).decode("ascii")
