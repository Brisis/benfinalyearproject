from wtforms import Form, StringField, DecimalField, IntegerField, TextAreaField, PasswordField, validators

#form used on Register page
class RegisterForm(Form):
    name = StringField('Full Name', [validators.Length(min=1,max=50)])
    username = StringField('Username', [validators.Length(min=4,max=25)])
    address = StringField('Address', [validators.Length(min=2, max=50)])
    email = StringField('Email', [validators.Length(min=6,max=50)])
    password = PasswordField('Password', [validators.DataRequired(), validators.EqualTo('confirm', message='Passwords do not match')])
    confirm = PasswordField('Confirm Password')

#form used on the Transactions page
class SignTxForm(Form):
    address = StringField('To Address', [validators.Length(min=4,max=50)])
    reference_number = StringField('Product Reference', [validators.Length(min=4,max=25)])
    amount = StringField('Amount', [validators.Length(min=1,max=50)])

#form used on the Transactions page
class RequestDeliveryForm(Form):
    account = StringField('Account', [validators.Length(min=4,max=50)])
    receiver_account = StringField('To Account', [validators.Length(min=4,max=50)])
    reference_number = StringField('Product Reference Number', [validators.Length(min=4,max=25)])
    private_key = StringField('Private Key (Sign/Validate Transaction)', [validators.Length(min=10,max=150)])

#form used on the Transactions page
class AcceptDeliveryForm(Form):
    account = StringField('Account', [validators.Length(min=4,max=50)])
    receiver_account = StringField('From Account', [validators.Length(min=4,max=50)])
    reference_number = StringField('Product Reference Number', [validators.Length(min=4,max=25)])
    private_key = StringField('Private Key (Sign/Validate Transaction)', [validators.Length(min=10,max=150)])

#form used on the Transactions page
class ApproveDeliveryForm(Form):
    account = StringField('Account', [validators.Length(min=4,max=50)])
    receiver_account = StringField('Receiver Account', [validators.Length(min=4,max=50)])
    pickup_account = StringField('Pickup Account', [validators.Length(min=4,max=50)])
    reference_number = StringField('Product Reference Number', [validators.Length(min=4,max=25)])
    private_key = StringField('Private Key (Sign/Validate Transaction)', [validators.Length(min=10,max=150)])

#form used on the Buy page
class BuyForm(Form):
    amount = StringField('Amount', [validators.Length(min=1,max=50)])
